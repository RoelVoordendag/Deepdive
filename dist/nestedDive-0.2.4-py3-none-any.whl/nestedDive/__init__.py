name = "hallo world"

print("This is a testing fase")